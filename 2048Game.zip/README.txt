本游戏由 李大恕<2928947343@qq.com> <QQ:2928947343> 编制，使用了 EasyX。
开源免费，仅供学习之用。
源代码详解详见 https://codebus.cn/aknoi/a/2048game